import React from "react";
import LocalStorage from "./localStorage";

const SubmitButton = () => {
  return <div></div>;
};

export default LocalStorage(SubmitButton);
