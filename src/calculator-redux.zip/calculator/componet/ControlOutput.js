import React from "react";

const CounterOutput = (props) => {
  return <div>Hasil: {props.value}</div>;
};

export default CounterOutput;
